import os
import tensorflow
import keras
import segmentation_models as sm
from zipfile import ZipFile
import datetime
import warnings
warnings.filterwarnings("ignore")

from phenoAI.Get_Pheno_Model.Json_to_mask import get_classes
from phenoAI.Get_Pheno_Model.data_preparation import Dataset,Dataloder
from phenoAI.Get_Pheno_Model.Augmentation import augmentation



class getPhenoModel:
    def __init__(self,dataset_path):

        assert os.path.isdir(dataset_path), dataset_path+", path does not exist or is not valid" 
        self.classes = get_classes(dataset_path)

        classes=self.classes
        dataset=Dataset(dataset_path,classes,augmentation=augmentation())

        BATCH_SIZE = int(0.03*len(dataset))
        if BATCH_SIZE==0:
            BATCH_SIZE=1
        Indexes=list(range(0,len(dataset)))
        dataloader = Dataloder(Indexes,dataset, batch_size=BATCH_SIZE, shuffle=True)

        BACKBONE = 'efficientnetb3'
        LR = 0.0005
        EPOCHS = 15
        preprocess_input = sm.get_preprocessing(BACKBONE)
        n_classes = len(self.classes.split('$'))+1
        activation = 'softmax'
        sm.set_framework('tf.keras')
        self.model = sm.Unet(BACKBONE, classes=n_classes, activation=activation)
        
        optim = keras.optimizers.Adam(LR)
        dice_loss = sm.losses.DiceLoss()
        focal_loss = sm.losses.BinaryFocalLoss()
        total_loss = dice_loss + (1 * focal_loss)
        metrics = [sm.metrics.IOUScore(threshold=0.5), sm.metrics.FScore(threshold=0.5)]
        self.model.compile(optim, total_loss, metrics)
        callbacks = [
            keras.callbacks.ModelCheckpoint('/content/best_model.h5', save_weights_only=True, save_best_only=True, mode='min'),
            keras.callbacks.ReduceLROnPlateau(),
        ]
        print("Traing the model...")
        history = self.model.fit(
            dataloader, 
            steps_per_epoch=len(dataloader), 
            epochs=EPOCHS, 
            callbacks=callbacks,    
        )


    def saveModel(self,path_location):
        current_time = datetime.datetime.now()
        current_time=current_time.strftime("%m-%d-%Y_%H.%M")
        curr_name=current_time+"_model"
        zip_name="/"+curr_name+".zip"
        if (path_location[-4:]=='.zip' or path_location[-4:]=='.ZIP'):
            i=-1
            l=len(path_location)
            while(i>-l and (path_location[i]!='/' and path_location[i]!='\\')):
                i-=1
            if(i==-l):
                zip_name=path_location
                path_location=""
            else:
                zip_name=path_location[i:]
                path_location=path_location[0:i]

        assert os.path.exists(path_location), path_location+ " , path does not exist or is not valid"

        zip_name=path_location+zip_name
        model_path=path_location+curr_name+".h5"

        self.model.save(model_path)
        with ZipFile(zip_name, 'w') as zip:
            zip.write(model_path,curr_name+'_Model.h5')
            zip.writestr('classes.txt',self.classes)
        os.remove(model_path)
        print("Model saved to ",zip_name)
        
    def returnModel(self):
        return [self.model,self.classes]
