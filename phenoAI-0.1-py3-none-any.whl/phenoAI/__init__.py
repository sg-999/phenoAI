from phenoAI.Get_Pheno_Model.main import getPhenoModel
from phenoAI.Build_Pheno_AI.main import buildPhenoAI
from phenoAI.set_date_formate.main import formatFilesName

print(
'''Documentation:
This Package contains three module-

1. formatFilesName(dataset_path,date_format,start_index): To rename images file names that help in extracting Date from file name. File formating is mandatory before analysis.
Here, dataset_path: location of image data and labels,
date_format: format of the date which is written in all files name.It should contains 'yyyy', 'dd' and 'mm'. For examples: 'yyyy-mm-dd' for (2019-05-11), 'mmddyyyy' for(04221999) etc.
index: It is the index in filenames from where date_format starts/ends. It must be same for all files. Consider name of the file without its extesion. Date index must be >= 1 (from left to right) or <= -1 (from right to left). 
For example suppose file names are like-  'Screenshot_20221204-15:22:59-586_com.google.jpg', here, date_formate is 'yyyymmdd'(20221204) and index is 12(12th position from start in the file name). For 'assgrhekjnigen_04-11-2021_WA.png', date_format is 'mm-dd-yyyy'(04-11-2021) and index is -4 (4th position from back in the file name, not considering .png as part of file name). Choose index(from start or end) according to pattern of filenames, such that this index must be same for all files names.

2.getPhenoModel(dataset_path): To make phenological Model by training through Image Dataset.
dataset_path: dataset location(Containing images and labels).
it has below functions:
saveModel(path_location): Where phenological Model to be saved. You can provide folder location(model will be saved by default name in that folder) or folder location along with model name in zip format, for example- 'C:/your_model_name.zip'
returnModel() : return phenological model object, that can be used further during analysis.

3. buildPhenoAI(model,dataset_path,class_name): To make analysis object. It provides phenological parameters, chronological coefficients, plots etc.
Here, model: it can be model zip file location or phenological model object obtained by getPhenoModel module
dataset_path: Images location
class_name: name of tree category on which you want to analyse. Name should be matching with one of the names used while labelling the dataset
This module object associates below functions:
showROIs(): shows images with ROIs selected
saveROIsImage(path_location): save this ROIs Image in the provided path_location.
setInitialParameters(min, max, slope1, SoS, slope2 , EoS): set initial parameters of plotting function for all GCC,BCC,RCC
setInitialGCCParameters(min, max, slope1, SoS, slope2 , EoS): same used for individual GCC
setInitialBCCParameters(min, max, slope1, SoS, slope2 , EoS): for BCC
setInitialECCParameters(min, max, slope1, SoS, slope2 , EoS): for RCC
extractGCCParameters(): Gives 6 phenological parameters
extractBCCParameters(): for BCC
extractRCCParameters(): for RCC
plotGCC(): plots GCC verses Day of Year(DoY) graph
plotGCC(),plotRCC(): for BCC and RCC
saveGCCPlot(path_location):save GCC vs DoY plot images in given location
saveBCCPlot(path_location),saveRCCPlot(path_location) for BCC and RCC
saveCCsTimeSeries(path_location): save all record GCC,BCC,RCC, 6 parameters in Excel file in the given location

'''
)