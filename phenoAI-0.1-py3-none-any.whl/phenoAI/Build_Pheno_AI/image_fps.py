import datetime
import os
from tqdm import tqdm
import numpy as np
def datestdtojd (stddate):
    fmt='%Y%m%d'
    sdtdate = datetime.datetime.strptime(stddate, fmt)
    sdtdate = sdtdate.timetuple()
    jdate = sdtdate.tm_yday
    return(jdate)

def get_image_fps(dataset_path,required_rois):
    images_fps=[]
    DoY=[]
    for dirpath, dirnames, filenames in os.walk(dataset_path):
        for file in tqdm([f for f in filenames if(f.endswith('.JPG') or f.endswith('.jpg') or f.endswith('.jpeg') or f.endswith('.JPEG'))],disable=True):
            src=dirpath + '/' + file
            images_fps.append(src)

            date=file.split('-')
            year=date[0]
            month=date[1]
            day=date[2]
            date=year+month+day
            jullion=datestdtojd(date)
            for _ in range(required_rois):
                DoY.append(jullion)
    DoY=np.array(DoY)
    return DoY,images_fps