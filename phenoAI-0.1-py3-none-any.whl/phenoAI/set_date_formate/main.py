import os
def formatFilesName(dataset_path,date_format,index):

    assert index!=0,"Date start index must be >= 1 (from left to right) or <= -1 (from right to left). It is the index in filename from where date format starts. It must be same for all files. Consider name of the file without its extesion."

    if index>0:
        index-=1
    end_index=index+len(date_format)-1
    d = [i for i in range(len(date_format)) if date_format.startswith('dd', i)]
    m=[i for i in range(len(date_format)) if date_format.startswith('mm', i)]
    y=[i for i in range(len(date_format)) if date_format.startswith('yyyy', i)]

    assert len(d)==len(m)==len(y)==1, "Date format is not appropriate, it should contains 'yyyy', 'dd' and 'mm'. For examples: yyyy-mm-dd for (2019-05-11), mmddyyyy for(04221999) etc."

    d=d[0]+index
    y=y[0]+index
    m=m[0]+index
    for dirpath, dirnames, filenames in os.walk(dataset_path):
        for file in filenames:
            extension=""
            file_name=file
            i=-1
            while(i!=-len(file) and file[i]!='.'):
                i-=1
            if i!=-len(file):
                file_name=file[0:i]
                extension=file[i:]

            assert end_index<0 or end_index<len(file_name), " Date start index or/and date format are not correct for file "+dirpath+'/'+file+"\nNote: 1. Date format should contains 'yyyy', 'dd' and 'mm'. For examples: yyyy-mm-dd for (2019-05-11), mmddyyyy for(04221999) etc."+"\n      2. Date start index is the index of name of file from where date format starts, It must be >= 1 (from left to right) or <= -1 (from right to left). It must be same for all files"+"\n      3. Consider name of the file without its extesion "
            
            if(y>=0 or y+4<0):
                year=file_name[y:y+4]
            else:
                year=file_name[y:]
            if(m>=0 or m+2<0):
                month=file_name[m:m+2]
            else:
                month=file_name[m:]
            if(d>=0 or d+2<0):
                day=file_name[d:d+2]
            else:
                day=file_name[d:]

            try:
                int(year)
                int(day)
                int(month)
            except:
                assert 0, " Date start index or/and date format are not correct for file "+dirpath+'/'+file+"\nNote: 1. Date format should contains 'yyyy', 'dd' and 'mm'. For examples: yyyy-mm-dd for (2019-05-11), mmddyyyy for(04221999) etc."+"\n      2. Date start index is the index of name of file from where date format starts, It must be >= 1 (from left to right) or <= -1 (from right to left). It must be same for all files"+"\n      3. Consider name of the file without its extesion "
            
            old_name = dirpath+'/'+file
            new_name = dirpath+'/'+year+'-'+month+'-'+day+'-'+file_name[0:index]
            if end_index!=-1 and end_index!=len(file_name)-1: 
                new_name+=file_name[end_index+1:]
            new_name+=extension
            os.rename(old_name, new_name)
    print("All files renamed!")

            